package com.example.myapplication.ui.main

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.ColorRes
import androidx.lifecycle.Observer
import com.example.myapplication.R
import kotlinx.android.synthetic.main.dummy_view.*
import kotlinx.android.synthetic.main.main_fragment.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.MainScope

class MainFragment : Fragment(), CoroutineScope by MainScope() {

    @ColorRes
    private var selectedColor: Int = R.color.black

    private var clicks = 0

    private fun setButtonSelected(view: View, color: Int) {
        selectedColor = color

        arrayOf(button_black, button_orange, button_blue, button_green).forEach {
            it.alpha = if (view.id == it.id) 0.5F else 1F
        }

        clicks++
    }


    companion object {
        fun newInstance() = MainFragment()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.main_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        root.setOnTouchListener { v, event ->

            if(event.action == MotionEvent.ACTION_UP) {
                val touchX  = event.x
                val touchY = event.y

                Toast.makeText(requireContext(), "Location: $touchX $touchY", Toast.LENGTH_LONG).show()

                val view: View = layoutInflater.inflate(R.layout.dummy_view, root, false)

                view.setBackgroundColor(resources.getColor(selectedColor, null))

                val label = dummy_view.findViewById<TextView>(R.id.label)

                root.addView(view)

                label.text = clicks.toString()

                view.x = touchX

                view.y = touchY
            }

            true
        }

        button_black.setOnClickListener { setButtonSelected(it, R.color.black) }

        button_orange.setOnClickListener { setButtonSelected(it, R.color.orange) }

        button_blue.setOnClickListener { setButtonSelected(it, R.color.blue) }

        button_green.setOnClickListener { setButtonSelected(it, R.color.green) }

        setButtonSelected(button_black, R.color.black)
    }
}
